package org.karasiksoftware.activities

// In this code "meeting" means: lesson, class. (рус. Пара, урок, занятие)

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.karasiksoftware.classes.*
import org.karasiksoftware.dataclasses.requests.meetings.Meeting


class DayTableActivity : AppCompatActivity() {
    private val origDisplayWidth = Resources.getSystem().displayMetrics.widthPixels // Width of phone display (need for correct animations)

    private lateinit var recycler: RecyclerView
    private lateinit var headerText: TextView
    private lateinit var toMonthTableButton: ImageButton
    private lateinit var preferencesButton: ImageButton
    private lateinit var downloadAnimationItem: ImageView
    private lateinit var downloadAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_day_table)

        recycler = findViewById(R.id.recycler)
        headerText = findViewById(R.id.header_text)
        toMonthTableButton = findViewById(R.id.button)
        preferencesButton = findViewById(R.id.preferences_button)
        downloadAnimationItem = findViewById(R.id.animation_item)
        downloadAnimation = AnimationUtils.loadAnimation(this, R.anim.shedule_animation)

        toMonthTableButton.setOnClickListener {
            val intent = Intent(this@DayTableActivity, MonthTableActivity::class.java)
            startActivity(intent)
        }

        preferencesButton.setOnClickListener {
            val intent = Intent(this@DayTableActivity, PreferencesActivity::class.java)
            intent.putExtra("previous_activity", "day_table")
            startActivity(intent)
        }

        getDay()
    }

    // Executes code from changeTable arg after successful request to server
    @OptIn(DelicateCoroutinesApi::class)
    private fun withAsyncRequest(month: Int, year: Int, token: String, changeTable: (data: Map<String, List<Meeting>>) -> Unit) {
        val request = Request()

        GlobalScope.launch {
            downloadAnimationItem.alpha = 1f
            downloadAnimationItem.startAnimation(downloadAnimation)

            val data = request.getData(month, year, token)

            runOnUiThread {
                changeTable(data)
            }
        }
    }

    @SuppressLint("SetTextI18n", "ClickableViewAccessibility")
    private fun getDay() {
        withAsyncRequest(currentDate.monthValue, currentDate.year, token) { data ->
            val calendar = Calendar()
            val dateTranslator = DateTranslator()
            val day = calendar.getDaySchedule(data, currentDate)
            val centerText: TextView = findViewById(R.id.center_text)

            headerText.text = "${dateTranslator.getRusDayOfWeek(currentDate.dayOfWeek.value)}, " +
                    "${currentDate.dayOfMonth} ${dateTranslator.getRusMonth(currentDate.monthValue)}"

            // If in that day no meetings, display text "Нет пар"
            if(day.meetings.isEmpty()) { centerText.text = "Нет пар" } else { centerText.text = "" }

            // Init RecyclerLayout
            recycler.layoutManager = LinearLayoutManager(this@DayTableActivity)
            recycler.adapter = CustomRecyclerAdapter(day.meetings)

            recycler.animate()
                .x(0f)
                .alpha(1f)
                .setDuration(300)
                .start()


            recycler.setOnTouchListener(object : AnimatedSwipeListener() {
                override fun onSwipeLeft() {
                    super.onSwipeRight()

                    recycler.animate()
                        .x(origDisplayWidth.toFloat())
                        .alpha(0f)
                        .setDuration(300)
                        .start()

                    recycler.animate()
                        .x(-origDisplayWidth.toFloat())
                        .setDuration(0)
                        .start()

                    // Decrement day
                    currentDate = currentDate.minusDays(1)

                    // Skip day if it`s Sunday
                    if (currentDate.dayOfWeek.value == 7) {
                        currentDate = currentDate.minusDays(1)
                    }

                    getDay()
                }

                override fun onSwipeRight() {
                    super.onSwipeLeft()

                    recycler.animate()
                        .x(-origDisplayWidth.toFloat())
                        .alpha(0f)
                        .setDuration(300)
                        .start()

                    recycler.animate()
                        .x(origDisplayWidth.toFloat())
                        .setDuration(0)
                        .start()

                    // Increment day
                    currentDate = currentDate.plusDays(1)

                    // Skip day if it`s Sunday
                    if (currentDate.dayOfWeek.value == 7) {
                        currentDate = currentDate.plusDays(1)
                    }

                    getDay()
                }
            })

            downloadAnimationItem.alpha = 0f
            downloadAnimationItem.clearAnimation()
        }
    }
}