package org.karasiksoftware.dataclasses.requests.meetings

@kotlinx.serialization.Serializable
data class MeetingInfo(
    val moduleName: String? = null,
    val theme: String? = null,
    val aud: String? = null,
    val link: String? = null,
    val teachersNames: String? = null,
    val groupName: String? = null,
    val type: String? = null,
)
