package org.karasiksoftware.dataclasses.requests.meetings

@kotlinx.serialization.Serializable
data class Meeting(
    val name: String? = null,
    val color: String? = null,
    val start: String? = null,
    val end: String? = null,
    private val info: MeetingInfo? = null
) {
    private val inf = info!!
    val module = inf.moduleName
    val theme = inf.theme
    val aud = inf.aud
    val teachers = inf.teachersNames
    val group = inf.groupName
    val type = inf.type
    val link = inf.link
    val startTime = start!!.slice(11..15)
    val endTime = end!!.slice(11..15)
}
