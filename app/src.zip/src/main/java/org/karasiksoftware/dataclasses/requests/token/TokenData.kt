package org.karasiksoftware.dataclasses.requests.token

import kotlinx.serialization.Serializable

@Serializable
data class TokenData(
    val accessToken: String? = null
)
