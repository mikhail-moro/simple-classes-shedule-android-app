package org.karasiksoftware.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.karasiksoftware.classes.Calendar
import org.karasiksoftware.classes.Request
import java.time.LocalDate

lateinit var token: String
lateinit var usernameStr: String
lateinit var passwordStr: String

var isAutoAuthorizeOn: Boolean = false

class LoginActivity : AppCompatActivity() {
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var message: TextView
    private lateinit var loginButton: Button
    private lateinit var check: CheckBox
    private lateinit var request: Request
    private lateinit var data: SharedPreferences
    private lateinit var downloadAnimationItem: ImageView
    private lateinit var downloadAnimation: Animation
    private lateinit var calendar: Calendar
    private lateinit var date: LocalDate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_login)

        username = findViewById(R.id.username)
        password = findViewById(R.id.password)
        loginButton = findViewById(R.id.login)
        message = findViewById(R.id.message)
        check = findViewById(R.id.check)
        downloadAnimationItem = findViewById(R.id.login_animation_item)
        downloadAnimation = AnimationUtils.loadAnimation(this, R.anim.login_animation)

        request = Request()
        data = getSharedPreferences("data", Context.MODE_PRIVATE)
        date = LocalDate.now()

        val usernameData = data.getString("username", "")
        val passwordData = data.getString("password", "")
        val enableNotifications = data.getBoolean("enable_notifications", true)

        if (usernameData!! != "" && passwordData!! != "") {
            isAutoAuthorizeOn = true

            username.alpha = 0f
            password.alpha = 0f
            loginButton.alpha = 0f
            message.alpha = 0f
            check.alpha = 0f

            usernameStr = usernameData
            passwordStr = passwordData

            downloadAnimationItem.alpha = 1f
            downloadAnimationItem.startAnimation(downloadAnimation)

            asyncRequest(usernameStr, passwordStr, enableNotifications)
        } else {
            loginButton.isClickable = true

            loginButton.setOnClickListener {
                val usernameText = username.text.toString()
                val passwordText = password.text.toString()

                if (usernameText == "" || passwordText == "") {
                    message.text = "Введите почту и пароль"

                    username.setOnClickListener {
                        message.text = ""
                    }
                    password.setOnClickListener {
                        message.text = ""
                    }
                } else {
                    usernameStr = usernameText
                    passwordStr = passwordText

                    downloadAnimationItem.alpha = 1f
                    downloadAnimationItem.startAnimation(downloadAnimation)

                    asyncRequest(usernameStr, passwordStr, enableNotifications)
                }
            }
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun asyncRequest(user: String, pass: String, enableNotifications: Boolean) {
        GlobalScope.launch {
            try {
                val response = request.getToken(user, pass)
                token = response.token

                runOnUiThread {
                    downloadAnimationItem.alpha = 0f
                    downloadAnimationItem.clearAnimation()

                    val intent = Intent(this@LoginActivity, MonthTableActivity::class.java)
                    startActivity(intent)

                    if (check.isChecked) {
                        val editor = data.edit()

                        editor.putString("username", usernameStr)
                        editor.putString("password", passwordStr)

                        editor.apply()
                    }
                }
            } catch (exception: Exception) {
                runOnUiThread {
                    message.alpha = 1f
                    loginButton.alpha = 1f

                    message.text = "Ошибка сервера"
                    loginButton.text = "Попробовать ещё раз"
                }
            }
        }
    }
}