package org.karasiksoftware.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.karasiksoftware.activities.R
import org.karasiksoftware.dataclasses.requests.meetings.Meeting

class NotificationUtils {
    companion object {
        const val NOTIFICATION_ID: Int = 10
        const val CHANNEL_ID = "10"
        const val ACTION_NEXT_MEETING = "nextMeeting"
        const val ACTION_PREV_MEETING = "prevMeeting"
    }

    private fun SharedPreferences.Editor.putStringList(key: String, values: List<String?>) {
        this.putString(key, values.joinToString("#"))
    }

    private fun setMeetingsToMemory(context: Context, startData: List<Meeting>) {
        val data = context.getSharedPreferences("data", Context.MODE_PRIVATE)
        val editor = data.edit()

        editor.putInt("meetingsSize", startData.size)
        editor.putInt("meetingsIndex", 0)
        editor.putStringList("meetingsNames", startData.map { it.name }.toList())
        editor.putStringList("meetingsStarts", startData.map { it.start!!.slice(11..15) }.toList())
        editor.putStringList("meetingsEnds", startData.map { it.end!!.slice(11..15) }.toList())
        editor.putStringList("meetingsAuds", startData.map { it.aud }.toList())
        editor.apply()
    }

    fun displayNotification(context: Context, startData: List<Meeting>) {
        context.startService(Intent(context, NotificationsService::class.java))

        val nextMeetingIntent = Intent(context, NotificationsService::class.java)
            .setAction(ACTION_NEXT_MEETING)
        val prevMeetingIntent = Intent(context, NotificationsService::class.java)
            .setAction(ACTION_PREV_MEETING)

        val nextMeetingPendingIntent = PendingIntent.getService(
            context,
            0,
            nextMeetingIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        val prevMeetingPendingIntent = PendingIntent.getService(
            context,
            0,
            prevMeetingIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val nextAction = NotificationCompat.Action(R.drawable.forward, "СЛЕД", nextMeetingPendingIntent)
        val prevAction = NotificationCompat.Action(R.drawable.back, "ПРЕД", prevMeetingPendingIntent)
        val notificationBuilder = NotificationCompat.Builder(context, CHANNEL_ID)

        val notificationManager = NotificationManagerCompat.from(context)
        val notificationChanel = NotificationChannel(CHANNEL_ID, "Today`s meetings", NotificationManager.IMPORTANCE_DEFAULT)

        notificationChanel.description = "Today`s meetings"
        notificationChanel.setShowBadge(true)
        notificationChanel.enableVibration(false)
        notificationChanel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        notificationManager.createNotificationChannel(notificationChanel)

        setMeetingsToMemory(context, startData)

        if (startData.isNotEmpty()) {
            val meeting = startData[0]

            notificationBuilder
                .setSmallIcon(R.mipmap.main_icon)
                .setContentTitle(meeting.name)
                .setContentText("${meeting.start!!.slice(11..15)}-${meeting.end!!.slice(11..15)}, ${meeting.aud}")
                .setOngoing(true)
                .addAction(prevAction)
                .addAction(nextAction)
        } else {
            notificationBuilder
                .setSmallIcon(R.mipmap.main_icon)
                .setContentTitle("Сегодня нет пар")
                .setContentText("")
                .setOngoing(true)
                .addAction(prevAction)
                .addAction(nextAction)
        }

        notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build())
    }
}