package org.karasiksoftware.notifications

import android.app.*
import android.app.AlarmManager.INTERVAL_DAY
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.karasiksoftware.activities.R
import org.karasiksoftware.classes.Calendar
import org.karasiksoftware.classes.Request
import java.time.LocalDate


class NotificationsService : IntentService(this::class.java.name) {
    private lateinit var notificationBuilder: NotificationCompat.Builder
    private lateinit var notificationManager: NotificationManagerCompat
    private lateinit var notificationChanel: NotificationChannel
    private lateinit var prevAction: NotificationCompat.Action
    private lateinit var nextAction: NotificationCompat.Action

    companion object {
        const val NOTIFICATION_ID = 10
        const val ACTION_NEXT_MEETING = "nextMeeting"
        const val ACTION_PREV_MEETING = "prevMeeting"
        const val ACTION_UPDATE_MEETINGS = "updateMeetings"
        const val CHANNEL_ID = "10"
    }

    private fun SharedPreferences.getStringList(key: String, defValues: List<String?>?) : List<String> {
        return this.getString(key, defValues.toString())!!.splitToSequence('#').toList()
    }

    private fun SharedPreferences.Editor.putStringList(key: String, values: List<String?>) {
        this.putString(key, values.joinToString("#"))
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun updateMeetingsRequest(editor: SharedPreferences.Editor, username: String, password: String) {
        val date = LocalDate.now()
        val request = Request()
        val calendar = Calendar()

        GlobalScope.launch {
            val token = request.getToken(username, password).token
            val data = request.getData(date.monthValue, date.year, token)
            val meetingsData = calendar.getNotificationDaySchedule(data, date)

            editor.putInt("meetingsSize", meetingsData.size)
            editor.putInt("meetingsIndex", 0)
            editor.putStringList("meetingsNames", meetingsData.map { it.name }.toList())
            editor.putStringList("meetingsStarts", meetingsData.map { it.start!!.slice(11..15) }.toList())
            editor.putStringList("meetingsEnds", meetingsData.map { it.end!!.slice(11..15) }.toList())
            editor.putStringList("meetingsAuds", meetingsData.map { it.aud }.toList())
        }

        editor.apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onCreate() {
        notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
        notificationManager = NotificationManagerCompat.from(this)
        notificationChanel = NotificationChannel(CHANNEL_ID, "Today`s meetings", NotificationManager.IMPORTANCE_DEFAULT)

        notificationChanel.description = "Today`s meetings"
        notificationChanel.setShowBadge(true)
        notificationChanel.enableVibration(false)
        notificationChanel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        notificationManager.createNotificationChannel(notificationChanel)

        super.onCreate()
    }

    @Deprecated("Deprecated in Java")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    @Deprecated("Deprecated in Java")
    override fun onHandleIntent(intent: Intent?) {
        val data = getSharedPreferences("data", Context.MODE_PRIVATE)
        val editor = data.edit()

        intent?.action?.let { Log.w("karasiki", it) }
        Log.w("karasiki", data.getStringList("meetingsNames", emptyList()).toString())
        Log.w("karasiki", data.getStringList("meetingsStarts", emptyList()).toString())
        Log.w("karasiki", data.getStringList("meetingsEnds", emptyList()).toString())
        Log.w("karasiki", data.getStringList("meetingsAuds", emptyList()).toString())

        when(intent!!.action) {
            ACTION_NEXT_MEETING -> {
                val meetingsSize = data.getInt("meetingsSize", 0)
                var meetingsIndex = data.getInt("meetingsIndex", 0)

                meetingsIndex = if (meetingsIndex+1 in 0 until meetingsSize) {
                    meetingsIndex+1
                } else {
                    meetingsIndex
                }

                val nextMeetingPendingIntent = PendingIntent.getService(
                    this,
                    0,
                    Intent(this, NotificationsService::class.java)
                        .setAction(ACTION_NEXT_MEETING),
                    PendingIntent.FLAG_IMMUTABLE
                )
                val prevMeetingPendingIntent = PendingIntent.getService(
                    this,
                    0,
                    Intent(this, NotificationsService::class.java)
                        .setAction(ACTION_PREV_MEETING),
                    PendingIntent.FLAG_IMMUTABLE
                )

                nextAction = NotificationCompat.Action(R.drawable.forward, "СЛЕД", nextMeetingPendingIntent)
                prevAction = NotificationCompat.Action(R.drawable.back, "ПРЕД", prevMeetingPendingIntent)

                if (meetingsSize != 0) {
                    val meetingName = data.getStringList("meetingsNames", emptyList())[meetingsIndex]
                    val meetingStart = data.getStringList("meetingsStarts", emptyList())[meetingsIndex]
                    val meetingEnd = data.getStringList("meetingsEnds", emptyList())[meetingsIndex]
                    val meetingAud = data.getStringList("meetingsAuds", emptyList())[meetingsIndex]

                    notificationBuilder
                        .setSmallIcon(R.mipmap.main_icon)
                        .setContentTitle(meetingName)
                        .setContentText("${meetingStart}-${meetingEnd}, $meetingAud")
                        .setOngoing(true)
                        .addAction(prevAction)
                        .addAction(nextAction)
                } else {
                    notificationBuilder
                        .setSmallIcon(R.mipmap.main_icon)
                        .setContentTitle("Сегодня нет пар")
                        .setContentText("")
                        .setOngoing(true)
                        .addAction(prevAction)
                        .addAction(nextAction)
                }

                notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build())

                editor.putInt("meetingsIndex", meetingsIndex)
                editor.apply()
            }
            ACTION_PREV_MEETING -> {
                val meetingsSize = data.getInt("meetingsSize", 0)
                var meetingsIndex = data.getInt("meetingsIndex", 0)

                meetingsIndex = if (meetingsIndex-1 in 0 until meetingsSize) {
                    meetingsIndex-1
                } else {
                    meetingsIndex
                }

                val nextMeetingPendingIntent = PendingIntent.getService(
                    this,
                    0,
                    Intent(this, NotificationsService::class.java)
                        .setAction(ACTION_NEXT_MEETING),
                    PendingIntent.FLAG_IMMUTABLE
                )
                val prevMeetingPendingIntent = PendingIntent.getService(
                    this,
                    0,
                    Intent(this, NotificationsService::class.java)
                        .setAction(ACTION_PREV_MEETING),
                    PendingIntent.FLAG_IMMUTABLE
                )

                nextAction = NotificationCompat.Action(R.drawable.forward, "СЛЕД", nextMeetingPendingIntent)
                prevAction = NotificationCompat.Action(R.drawable.back, "ПРЕД", prevMeetingPendingIntent)

                if (meetingsSize != 0) {
                    val meetingName = data.getStringList("meetingsNames", emptyList())[meetingsIndex]
                    val meetingStart = data.getStringList("meetingsStarts", emptyList())[meetingsIndex]
                    val meetingEnd = data.getStringList("meetingsEnds", emptyList())[meetingsIndex]
                    val meetingAud = data.getStringList("meetingsAuds", emptyList())[meetingsIndex]

                    notificationBuilder
                        .setSmallIcon(R.mipmap.main_icon)
                        .setContentTitle(meetingName)
                        .setContentText("${meetingStart}-${meetingEnd}, $meetingAud")
                        .setOngoing(true)
                        .addAction(prevAction)
                        .addAction(nextAction)
                } else {
                    notificationBuilder
                        .setSmallIcon(R.mipmap.main_icon)
                        .setContentTitle("Сегодня нет пар")
                        .setContentText("")
                        .setOngoing(true)
                        .addAction(prevAction)
                        .addAction(nextAction)
                }

                notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build())

                editor.putInt("meetingsIndex", meetingsIndex)
                editor.apply()
            }
            ACTION_UPDATE_MEETINGS -> {
                Log.w("karasiki", "блять")
                val username = data.getString("username", "")
                val password = data.getString("password", "")

                updateMeetingsRequest(editor, username!!, password!!)

                val changedData = getSharedPreferences("data", Context.MODE_PRIVATE)

                val nextMeetingPendingIntent = PendingIntent.getService(
                    this,
                    0,
                    Intent(this, NotificationsService::class.java)
                        .setAction(ACTION_NEXT_MEETING),
                    PendingIntent.FLAG_IMMUTABLE
                )
                val prevMeetingPendingIntent = PendingIntent.getService(
                    this,
                    0,
                    Intent(this, NotificationsService::class.java)
                        .setAction(ACTION_PREV_MEETING),
                    PendingIntent.FLAG_IMMUTABLE
                )

                nextAction = NotificationCompat.Action(
                    R.drawable.forward,
                    "СЛЕД",
                    nextMeetingPendingIntent
                )
                prevAction = NotificationCompat.Action(
                    R.drawable.back,
                    "ПРЕД",
                    prevMeetingPendingIntent
                )

                val meetingsSize = changedData.getInt("meetingsSize", 0)
                Log.w("karasiki", "блять size - $meetingsSize")

                if (meetingsSize != 0) {
                    val meetingName = changedData.getStringList("meetingsNames", emptyList())[0]
                    val meetingStart = changedData.getStringList("meetingsStarts", emptyList())[0]
                    val meetingEnd = changedData.getStringList("meetingsEnds", emptyList())[0]
                    val meetingAud = changedData.getStringList("meetingsAuds", emptyList())[0]

                    notificationBuilder
                        .setSmallIcon(R.mipmap.main_icon)
                        .setContentTitle(meetingName)
                        .setContentText("${meetingStart}-${meetingEnd}, $meetingAud")
                        .setOngoing(true)
                        .addAction(prevAction)
                        .addAction(nextAction)
                } else {
                    notificationBuilder
                        .setSmallIcon(R.mipmap.main_icon)
                        .setContentTitle("Сегодня нет пар")
                        .setContentText("")
                        .setOngoing(true)
                        .addAction(prevAction)
                        .addAction(nextAction)
                }

                notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build())
            }
        }
    }
}
