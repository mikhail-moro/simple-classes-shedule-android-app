package org.karasiksoftware.dataclasses.requests.token

import kotlinx.serialization.Serializable

@Serializable
data class TokenRequestData(
    private val data: TokenData? = null,
    val state: Int? = null
) {
    val token = data?.accessToken!!
}
