package org.karasiksoftware.dataclasses.requests.meetings

@kotlinx.serialization.Serializable
data class MeetingsRequestData(
    private val data: MeetingsData? = null,
    val state: Int? = null
) {
    val meetings = data!!.meetingsMap
}